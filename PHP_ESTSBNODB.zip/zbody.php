<?php
/*
Coding By Mejd Yassine
*/

error_reporting(0);
$filesa = scandir(__DIR__."/txt/",SCANDIR_SORT_DESCENDING);
$files = scandir(__DIR__."/txt/");
function menu() {
global $filesa;
$min = 0;
$max = count($filesa)-3;
  
    while ($min <= $max) {

if (substr_count($filesa[$min], '__') == 0) {
if ($filesa[$min] != "404.txt") {
if ($filesa[$min] == $_GET['a']) {
       echo '<a target="_top" href="./'.$filesa[$min].'" class="active" >'.str_replace('_', ' ', $filesa[$min]).'</a>';
    }else{
       echo '<a target="_top" href="./'.$filesa[$min].'">'.str_replace('_', ' ', $filesa[$min]).'</a>';
    }
    }
    }
    $min++;
}
}




function nexta() {


global $files;

//$files = scandir(__DIR__."/txt/");

$min = 0;
$max = count($files);
 
    while ($min <= $max) {

if ($files[$min] == $_GET['a']) {
    if (substr_count($filesa[$min], '__') == 0) {
    $min++;
       echo $files[$min];
        break;    
    }else{
    $min++;
    }
    }else{
    $min++;
}}}
function prea() {


global $filesa;

$min = 0;
$max = count($filesa)-3;
  
    while ($min <= $max) {

if ($filesa[$min] == $_GET['a']) {
    $min++;
if ($filesa[$min] != "404.txt") {
    
if (substr_count($filesa[$min], '__') == 0) {
       echo $filesa[$min];
       }
        break;    
    }
    }else{
    $min++;
}}}

function body() {
global $files;

$min = 2;
$max = count($files);
  
//$lines = file($file);

while ($min <= $max) {
$re = str_replace('
','',$files[$min]);
    if ($_GET['a'] == $re) {
        $min = $max;
        break;    
    }else{$re = "404.txt";}

    $min++;
}

//$myfile = fopen(__DIR__."/txt/".$re, "r") or die("Unable to open file!");
//$file_size = filesize(__DIR__."/txt/".$re);
  //  if ($file_size == 0){ return "";
    //}

//$mjd = str_replace('.pdf', '',$mjd2);

if ($_GET['a']) {

ob_start();
include __DIR__."/txt/".$re;
$str_sidebar = ob_get_clean();
$body = str_replace(".pdf", "", $str_sidebar);


//$mjd = str_replace('.pdf', '',fread($myfile,$file_size));
echo str_replace('width="1000"', 'width="700"',$body);
//echo fread($myfile,filesize(__DIR__."/txt/".$re));
//fclose($myfile);
}else{
ob_start();
include __DIR__."/txt/Last_Article__";
$str_sidebar = ob_get_clean();
$body = str_replace(".pdf", "", $str_sidebar);
echo str_replace('width="1000"', 'width="700"',$body);
}
}



?>