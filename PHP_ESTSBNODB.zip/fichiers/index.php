<?php

//$file = __DIR__.'/pdf/'.$_GET['a'].'.pdf';
//echo $file;
//$filename = $_GET['a']; /* Note: Always use .pdf at the end. */

//header('Accept-Ranges: bytes');
header('Content-type: application/pdf');
//header("Content-disposition: inline; filename=".$filename);
//header('Content-Disposition: inline; filename="' . $filename . '"');
//header('Content-Transfer-Encoding: binary');
//header('Content-Length: ' . filesize($file));

$mjd = str_replace('.pdf', '',$_GET['a']);
echo file_get_contents("http://www.estsb.ucd.ac.ma/fichiers/".$mjd.'.pdf');

//@readfile($file);
?>