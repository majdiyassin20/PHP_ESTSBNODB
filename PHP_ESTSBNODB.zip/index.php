﻿<?php
/*
Coding By Mejd Yassine
*/



 include "zbody.php";?><html><head>

<title>Est Sb - <?php echo htmlspecialchars(str_replace('_', ' ',htmlspecialchars(str_replace('__', '',$_GET['a']), ENT_QUOTES, 'UTF-8')), ENT_QUOTES, 'UTF-8');?></title>



<meta name="Keywords" content="Est Sb">
<meta name="Description" content="Est Sb - Version Beta">
<meta charset="utf-8">
<link rel="stylesheet" href="./l/est-sb/w3.css">
<link rel="stylesheet" type="text/css" href="./l/est-sb/stdtheme.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href='https://fonts.googleapis.com/css?family=Source Code Pro' rel='stylesheet'>

<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(e) {
  if (!e.target.matches('.dropbtn')) {
  var myDropdown = document.getElementById("myDropdown");
    if (myDropdown.classList.contains('show')) {
      myDropdown.classList.remove('show');
    }
  }
}


/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunctiona() {
  document.getElementById("myDropdowna").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(e) {
  if (!e.target.matches('.dropbtn')) {
  var myDropdown = document.getElementById("myDropdowna");
    if (myDropdown.classList.contains('show')) {
      myDropdown.classList.remove('show');
    }
  }
}
</script>
<div class="w3-container top">
<a class="w3schools-logo" href="./">Est SB</a>
</div>
<div class="w3-card-2 topnav notranslate" id="topnav" style="position: relative; top: 0px;">
  <div style="overflow:auto;">
    <div class="w3-bar w3-left" style="width:100%;overflow:hidden;height:44px">
    <div class="navbar">
      <a href="javascript:void(0);" class="topnav-icons fa fa-menu w3-hide-large w3-left w3-bar-item w3-button" onclick="open_menu()" title="Menu"></a>
      <a href="/" class="topnav-icons fa fa-home w3-left w3-bar-item w3-button" title="Home"></a>
      
      
      
      
      <a class="w3-bar-item w3-button" href="./Actualites__" title="Actualites">Actualites</a>
      <a class="w3-bar-item w3-button" href="./Contact__" title="Contact">Contact</a>
      
      <div class="dropdown"><a class="w3-bar-item w3-button">
  <button class="dropbtn" onclick="myFunction()">Annonce (31-34)
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-content" id="myDropdown" style="
    margin-top: 40px;
" ><a class="w3-bar-item w3-button"></a><a class="w3-bar-item w3-button"></a><a href="./Annonce34">Annonce34</a>
    <a href="./Annonce33">Annonce33</a>
    <a href="./Annonce33">Annonce32</a>
    <a href="./Annonce33">Annonce31</a>
  </div></a>
  </div>
      
      
      
 <div class="dropdowna"><a class="w3-bar-item w3-button">
  <button class="dropbtn" onclick="myFunctiona()">Annonce (28-30)
    <i class="fa fa-caret-down"></i>
  </button>
  </a><div class="dropdown-content" id="myDropdowna" style="
    margin-top: 40px;
"><a class="w3-bar-item w3-button"></a><a class="w3-bar-item w3-button"></a><a class="w3-bar-item w3-button"></a><a href="./Annonce30">Annonce30</a>
    <a href="./Annonce29_2">Annonce29_(2)</a>
    <a href="./Annonce29_1">Annonce29_(1)</a>
    <a href="./Annonce28">Annonce28</a>
  </div>
  </div>

    </div>
   
  </div> 
    
  </div>
</div>

<div class="w3-sidebar w3-collapse" id="leftmenu" style="padding-top: 0px; display: none;">
<div id="leftmenuinner" style="padding-top: 112px;position: absolute;">
<div class="w3-light-grey" id="leftmenuinnerinner" style="
    margin-top: 30px;
">
<a href="javascript:void(0)" onclick="close_menu()" class="w3-closebtn w3-hide-large w3-large" style="padding:3px 12px;">×</a>
<h2 class="left"><span class="left_h2">Actualités</span></h2>
  <?php menu();?><br></div></div></div><div class="w3-row w3-light-grey" id="belowtopnav" style="padding-top: 0px;">

<div class="w3-main w3-light-grey" id="belowtopnav" style="margin-left: 220px; padding-top: 44px;">
    <div class="w3-row w3-white">
<div class="w3-col l10 m12" id="main">

<div class="w3-col l10 m12" id="main">
<?php 
if ($_GET['a']){
echo '<div class="chapter" style="visibility: visible;">
<div class="prev"><a class="chapter" href="./';
prea(); echo '" style="visibility: visible;">« Previous</a></div>
<div class="next"><a class="chapter" href="./';
nexta();  echo '" style="visibility: visible;">Next »</a></div>
</div>';}
?>
<br>
<h3><?php echo htmlspecialchars(str_replace('_', ' ',$_GET['a']), ENT_QUOTES, 'UTF-8');?></h3>
<hr style="height: 2px;/* color: #000000; */background-color: #0019cc;">
<?php body();?><br><div class="w3-col l10 m12" id="main">
<?php 
if ($_GET['a']){
echo '<div class="chapter" style="visibility: visible;">
<div class="prev"><a class="chapter" href="./';
prea(); echo '" style="visibility: visible;">« Previous</a></div>
<div class="next"><a class="chapter" href="./';
nexta();  echo '" style="visibility: visible;">Next »</a></div>
</div>';}
?>
</div>
</div>

<div class="w3-col l2 m12" id="right">



<div class="sidesection">
<img src="./colorpicker.gif" alt="colorpicker"></a>
</div>

<div class="sidesection" id="moreAboutSubject">
</div>



<div class="sidesection w3-light-grey" style="margin-left:auto;margin-right:auto;max-width:230px">
  <div class="w3-container w3-dark-grey">
    <h4><a href="#" class="w3-hover-text-white">Autre</a></h4>
  </div>
  <div class="w3-container w3-left-align w3-padding-16">
    <a href="./">Home</a><br>
    <a href="./Actualites__">Actualites</a><br>
    <a href="./Contact__">Contact</a><br>
    
  </div>
</div>
</div>

</div>









</div>
<div class="footer w3-container w3-white">      
<hr>
<br>
</div></div>
</div>

<div style="font-family: arial; font-size: 12px; padding: 2px; width: 100%; z-index: 100; background: rgb(68, 68, 68); color: rgb(255, 255, 255);"><div class="w3-center w3-small w3-opacity">
Programing By: Yassine Mejd
 <br>

</div>
<a href="#" style="color: white" target="_blank">.</a></div><div style="font-family: arial; font-size: 12px; padding: 2px; width: 100%; z-index: 100; background: rgb(68, 68, 68); color: rgb(255, 255, 255);"><a href="#" style="color: white" target="_blank">.</a></div></body></html>