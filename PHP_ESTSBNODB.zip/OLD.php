<?php

$m=array("janv" => "30","fev" => "31","mars" => "28","apr" => "30","mai" => "31","juin" => "30","juil" => "31","aug" => "31","sept" => "30","oct" => "31","nov" => "31","dec" => "30");
//var_dump($m);


echo"<table border=1>";
echo"<tr><td>";
echo current($m) . "</td>";
echo"<td>";
echo key($m). "</td>";
echo"</tr>";

for($i=1;$i<=11;$i++){

echo"<tr><td>";
echo next($m) . "</td>";
echo"<td>";
echo key($m). "</td>";
echo"</tr>";
}

echo"</table>";

?>
